/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruang
 */
public class salvaNumeros {
    private int Numero1;
    private String op;
     public void setNum(int n){
        Numero1 = n;
    }
    
    public int getNum(){
        return Numero1;
    }
    public void setOperacao(String opr){
    op = opr;
    }
    public String getOperacao(){
    return op;
    }
   
}
