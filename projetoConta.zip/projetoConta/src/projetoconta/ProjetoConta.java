/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoconta;

/**
 *
 * @author ruang
 */
public class ProjetoConta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conta c1 = new Conta();
        c1.nomeTitular="Rogerio";
        c1.agencia="0375-1";
        c1.numero= 1052;
        c1.saldo= 5000;
        c1.dataAbertura="11/02/2000";
        c1.mostraDados();
        c1.deposito(1500.50);
        c1.mostraDados();
        c1.saque(1000);
        c1.mostraDados();
        
        Conta c2 = new Conta();
        c2.nomeTitular="Rogerio";
        c2.agencia="0375-1";
        c2.numero= 1052;
        c2.saldo= 5000;
        c2.dataAbertura="11/02/2000";
        c2.mostraDados();
        c2.deposito(1500.50);
        c2.mostraDados();
        c2.saque(1000);
        c2.mostraDados();
        
        if(c1 == c2){
            System.out.println("São Iguais");
        }else{
            System.out.println("Não São Iguais");
        }
       

    }
    
}
