/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetocaneta;

/**
 *
 * @author ruang
 */
public class ProjetoCaneta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       caneta c1 = new caneta();
     
       c1.cor = "Vermelha";
       c1.modelo = "Bic Cristal";
       c1.status();
       c1.escrever();
       
       caneta c2 = new caneta();
        
       c2.cor = "Azul";
       c1.modelo = "Faber Castel";
       c2.status();
       c2.escrever();
    }
    
}
