/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoestudante;

/**
 *
 * @author ruang
 */
public class Estudante {
    private int codigo;
    private String nome;
    private String dataNasc;
    private double notaMat;
    private double notaPort;
    private double notaCien;
    double media;
    public void estudante(int cod, String getNome, String getDataNasc){
        codigo = cod;
        nome = getNome;
        dataNasc = getDataNasc;
        
        
    }
    public int getCodigo(){
        return codigo;
        
    }
    public String getNome(){
        return nome;
    }
    public void setNotas(double port, double mat, double cien){
        notaMat = mat;
        notaPort = port;
        notaCien = cien;
        
    }
    public void calculaMedia(){
        media = (notaMat + notaPort + notaCien) /3;
        System.out.println("A media final foi: "+ media);
    }
    public void addPonto(double add){
     media = media + add;
     System.out.println("A media final apos o aumento foi: "+media);
    }
    
    
}
