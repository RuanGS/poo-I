/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoestudante;

/**
 *
 * @author ruang
 */
public class ProjetoEstudante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estudante e1 = new Estudante();
        e1.estudante(1, "Josney","10/06/2020");
        e1.getNome();
        e1.getCodigo();
        e1.setNotas(8.3,7.8,6.5);
        e1.calculaMedia();
        e1.addPonto(0.8);
    }
    
}
