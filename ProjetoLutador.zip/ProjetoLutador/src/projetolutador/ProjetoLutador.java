/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetolutador;

/**
 *
 * @author ruang
 */
public class ProjetoLutador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Lutador l[] = new Lutador[4];
       l[0] = new Lutador("Pretty Boy", "Brasil", 20, 1.75f, 88.3f, 3, 3, 3);
       l[1] = new Lutador("Pretty Boy", "Brasil", 20, 1.75f, 88.3f, 3, 3, 3);
       l[2] = new Lutador("Pretty Boy", "Brasil", 20, 1.75f, 88.3f, 3, 3, 3);
       l[3] = new Lutador("Pretty Boy", "Brasil", 20, 1.75f, 88.3f, 3, 3, 3);
       
       Luta luta1 = new Luta();
       
       luta1.marcarLuta(l[1], l[3]);
       luta1.lutar();
    }
    
}
