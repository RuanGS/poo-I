/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetolutador;

/**
 *
 * @author ruang
 */
public class Lutador {
    private String nome;
    private String nacionalidade;
    private int idade;
    private double altura;
    private double peso;
    private String categoria;
    private int vitorias;
    private int derrotas;
    private int empates;

    public Lutador(String nome, String nacionalidade, int idade, double altura, double peso, int vitorias, int derrotas, int empates) {
        this.nome = nome;
        this.nacionalidade = nacionalidade;
        this.idade = idade;
        this.altura = altura;
        this.peso = peso;
        setCategoria();
        this.vitorias = vitorias;
        this.derrotas = derrotas;
        this.empates = empates;
    }

    
    
     public String getNome(){
     return nome;
     }
     public void setNome(String no){
     nome = no;
     }
     
     public double getPeso(){
     return peso;
     }
     public void setPeso(double pe){
     peso = pe;
     setCategoria();
     }
     public String getNasc(){
     return nacionalidade;
     }
     public void setNasc(String na){
     nacionalidade = na;
     }
     public int getIdade(){
     return idade;
     }
     public void setIdade(int id){
     idade = id;
     }
     public double getAltura(){
     return altura;
     }
     public void setAltura(int al){
     altura = al;
     }
     
     public void setCategoria(){
        if (peso < 52.2){
             categoria = "inválido";
        }else if(peso <= 70.3){
            categoria = "leve";
        }else if(peso <= 83.9){
            categoria = "medio";
        }else if(peso <= 83.9){
            categoria = "pesado";
        }else{
            categoria = "Inválido";
        }
     }
     public String getCategoria(){
     return categoria;
     }
    
    public int getVitorias(){
     return vitorias;
     }
     public void setVitorias(int vitorias){
     this.vitorias = vitorias;
     }
    public void ganharLuta(){
        setVitorias(getVitorias()+1);
    }
    public int getDerrotas(){
     return derrotas;
     }
     public void setDerrotas(int derrotas){
     this.derrotas = derrotas;
     }
    public void perderLuta(){
        setDerrotas(getDerrotas()+1);
    }
    public int getEmpates(){
     return empates;
     }
     public void setEmpates(int empates){
     this.empates = empates;
     }
    public void empatarLuta(){
        setEmpates(getEmpates()+1);
    }
     public void apresentar(){
         System.out.println("Lutador: " + getNome());
         System.out.println("Origem: " + getNasc());
         System.out.println(getIdade() + " Anos");
         System.out.println(getAltura() + " M de altura");
         System.out.println("Pesando: " + getPeso() + " KG");
         System.out.println("Ganhou " + getVitorias() + " Lutas");
         System.out.println("Perdeu " + getDerrotas() + " Lutas");
         System.out.println("Empatou " + getEmpates() + " Lutas");
    } 
    public void Stats(){
         System.out.println("Lutador: " + getNome());
         System.out.println(getIdade() + " Anos");
         System.out.println("Ganhou " + getVitorias() + " Lutas");
         System.out.println("Perdeu " + getDerrotas() + " Lutas");
         System.out.println("Empatou " + getEmpates() + " Lutas");
    }
}
