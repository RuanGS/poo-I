package projetolutador;


import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *

 */

public class Luta {
private Lutador desafiante;
private Lutador desafiado;
private int rounds;
private boolean aprovada;

public Lutador getDesafiado(){
    return desafiado;
}
public void setDesafiado(Lutador d1){
    desafiado = d1;
}
public Lutador getDesafiante(){
    return desafiante;
}
public void setDesafiante(Lutador d2){
    desafiante = d2;
}
public void marcarLuta(Lutador l1, Lutador l2){
    if(l1.getCategoria().equals(l2.getCategoria())){
        this.aprovada = true;
        this.desafiante = l2;
        this.desafiado = l1;
    }else{
        this.aprovada = false;
        this.desafiante = null;
        this.desafiado = null;
    }
}
public void lutar(){
    if(this.aprovada == true){
        this.desafiado.apresentar();
        System.out.println("-------------------- VS ----------------------");
        this.desafiante.apresentar();
        
        Random aleatorio = new Random();
        int vencedor = aleatorio.nextInt(3);
        switch(vencedor){
            case 0:
                System.out.println("Empate");
                this.desafiado.empatarLuta();
                this.desafiante.empatarLuta();
                break;
                case 1:
                System.out.println("Vitoria Desafiante");
                this.desafiante.ganharLuta();
                this.desafiado.perderLuta();
                break;
                case 2:
                System.out.println("Vitoria Desafiado");
                this.desafiado.ganharLuta();
                this.desafiante.perderLuta();
                break;
        }
    }else{
        System.out.println("Não háverá luta!");
    }
}

}
